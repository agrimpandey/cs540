My Name: Patrick LaChance
My Wisc ID: plachance
Partner's Name: Agrim Pandey
Partner's Wisc  ID: pandey7
Code is included in my submission